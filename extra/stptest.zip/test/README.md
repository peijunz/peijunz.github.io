## Prerequired
Copy your `Switch.py` to this test suite folder **only**. Do **not** overwrite `Topology.py`

## How to use
Then there are two ways to run `check_answer.py`:

+ Simply run `python check_answer.py` to test randomly generated cases
+ Run `python check_answer.py <topology_file> <log_file>` to check for some specific topology 
