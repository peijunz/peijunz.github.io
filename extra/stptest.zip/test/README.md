## How to use
+ Copy your `Switch.py` to this test suite folder **only**. Do **not** overwrite `Topology.py`
+ Simply run `python check_answer.py` to test randomly generated cases
