# How to use
There are two ways:
+ simply run `python check_answer.py` to test randomly generated cases
+ run `python check_answer.py <topology_file> <log_file` to check for some specific topology 

# Notes
1. **Only** copy your Switch.py to this test suite
2. Do not over write Topology.py
