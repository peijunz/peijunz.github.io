import sys
import numpy as np
from Topology import *

def minSpanningTree(G):
    '''Spanning Tree by BFS'''
    topo = dict([(i, set()) for i in G])
    rem = set(G.keys())
    visited = set()
    forest = 0
    while len(visited) < len(G):
        root = min(rem)
        frontier = {root,}
        visited.update(frontier)
        
        while frontier:
            '''BFS with priority of switch ID'''
            nexts = set()
            for i in sorted(frontier):
                for neighbor in G[i]:
                    if not (neighbor in visited or neighbor in nexts):
                        nexts.add(neighbor)
                        topo[i].add(neighbor)
            frontier = nexts
            visited.update(nexts)
        rem = rem - visited
        forest += 1
    if forest > 1:
        print "Not connected, there are {} forests".format(forest)
    return symmetrized(topo)

def SpanningTree(G):
    '''Spanning Tree by YOUR code'''
    topo = Topology(G)
    return topo.spanning_tree()

def symmetrized(topo):
    topo2 = [[i, list(topo[i])] for i in topo]
    for i, links in topo2:
        for j in links:
            topo[j].add(i)
    for s1 in topo:
        for s2 in topo[s1]:
            if not s1 in topo[s2]:
                print "Failed: not all neighbors links back"
                exit()
    return topo

def logstring(switch, links):
    return ', '.join('{} - {}'.format(switch, i) for i in sorted(links))

def check_graph(G):
    t1 = minSpanningTree(G)
    t2 = SpanningTree(G)
    print "Pass" if t1==t2 else "Fail: \nTopology: {}\n Answer: {}\nYour Answer: {}\n".format(G, t1, t2)
    assert t1 == t2
    return t1

def check_mod(mod):
    if mod.endswith('.py'):
        mod = mod[:-3]
    check_graph(__import__(mod).topo)
    
def randomGraph(n=10, p=3, rs=np.random, index_range_scale=3):
    '''
    Args:
        n:  number of nodes
        p:  Density or Connectivity. Meaning of p:
                + if p<1 it means the connection probability between any two points
                    + p=0 means tree, p=0.999 means very dense graph
                + if p>1 it means average number of links connected to each point
    '''
    if p >= 1:
        # P is now number of bonds
        p = p/(n*(n-1)/2.+0.1)
    nodes = rs.choice(np.arange(1, index_range_scale*n), n, replace=False)
    elems = [nodes[0],]
    G = {nodes[0]: set()}
    for node in nodes[1:]:
        links = (rs.random_sample(len(elems))<p).nonzero()[0]
        if len(links)==0:
            links = [rs.randint(len(elems))]
        G[node] = set(np.array(elems)[links])
        elems.append(node)
    return symmetrized(G)

modules = [
    "Sample",
    "NoLoopTopo",
    "SimpleLoopTopo",
    "ComplexLoopTopo",
    "TailTopo",
    "RandomTopo_1000",
    "RandomTopo_2000",
        ]

def check_mod_cli():
    if len(sys.argv) != 3:
        print "Syntax:"
        print "    python {} to run all test cases".format(sys.argv[0])
        print "    python {} <topology_file> <log_file>".format(sys.argv[0])
        exit()
    if sys.argv[1].endswith('.py'):
        sys.argv[1] = sys.argv[1][:-3]
    topo = check_graph(__import__(sys.argv[1]).topo)
    with open(sys.argv[2], 'w') as f:
        for switch, links in sorted(topo.items()):
            f.write(logstring(switch, links))
            f.write('\n')

def check_all(
    nlist=[5, 10, 100, 500, 1000],
    plist=[0, 0.999, 1.1, 1.2, 3, 10],
    repeat=10,
    rs=np.random.RandomState(0)
    ):
    '''
    Args:
        nlist:  Different test case sizes to test
        plist:  Different Graph density to test. Meaning of p:
                    + if p<1 it means the connection probability between any two points
                    + if p>1 it means average number of links connected to each point
        repeat: How many times to repeat for each (n, p) configuration
    '''
    for n in nlist:
        for p in plist:
            print "Number of nodes = {}, p = {}".format(n, p)
            for i in range(repeat):
                G = randomGraph(n, p, rs)
                #print G
                check_graph(G)
if __name__ == "__main__":
    if len(sys.argv) == 1:
        check_all()
    else:
        check_mod_cli()
